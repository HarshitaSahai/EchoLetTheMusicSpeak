package com.internshala.echo.Fragments


import android.app.Activity
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import com.internshala.echo.Fragments.AboutUsFragment.Staticated._about
import com.internshala.echo.R


class AboutUsFragment : Fragment() {
    object Staticated{
        var myActivity: Activity? = null
        var _about : RelativeLayout?=null
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater?.inflate(R.layout.fragment_about_us, container, false)
       _about = view?.findViewById(R.id._aboutUs)
        activity?.title = "About Us"
        return view
    }


}
